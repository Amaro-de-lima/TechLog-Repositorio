# TechLog Server Setup

Este repositório contém os arquivos necessários para configurar o ambiente inicial de servidor da startup **TechLog**.

## Arquivos

- `setup_infra.sh`: Script de automação para criação de usuários, grupos, permissões, configuração de cotas de disco e instalação do Apache.
- `index.html`: Página de exemplo servida pelo Apache após configuração.

## Como executar

1. Clone este repositório:
   ```bash
   git clone <URL_DO_REPOSITORIO>
   ```
2. Dê permissão de execução ao script:
   ```bash
   chmod +x setup_infra.sh
   ```
3. Execute o script:
   ```bash
   ./setup_infra.sh
   ```

## Requisitos

- Ubuntu Server 22.04 LTS
- Permissões de superusuário (sudo)

---
**Autor:** Equipe de Configuração TechLog
