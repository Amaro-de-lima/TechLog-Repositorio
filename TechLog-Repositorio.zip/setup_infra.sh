#!/bin/bash
# Script de automação para configuração inicial do servidor TechLog

# Criar grupos
sudo groupadd desenvolvedores
sudo groupadd operacoes

# Criar usuários
sudo useradd -m -G desenvolvedores dev1
sudo useradd -m -G desenvolvedores dev2
sudo useradd -m -G operacoes ops1
sudo useradd -m -G operacoes ops2
sudo useradd -m -G desenvolvedores,operacoes techlead

# Criar diretório e definir permissões
sudo mkdir -p /srv/app
sudo chgrp desenvolvedores /srv/app
sudo chmod 770 /srv/app
sudo setfacl -m g:operacoes:rx /srv/app

# Habilitar cotas de disco
sudo apt install quota -y
sudo mount -o remount,usrquota /home
sudo quotacheck -cum /home
sudo quotaon /home
for user in dev1 dev2 ops1 ops2 techlead; do
    sudo setquota -u $user 200000 250000 0 0 /home
done

# Atualizar pacotes e instalar Apache
sudo apt update
sudo apt install apache2 -y

# Criar página HTML
echo "<h1>Bem-vindo à TechLog</h1>" | sudo tee /srv/app/index.html

# Configurar Apache para servir /srv/app
echo "<VirtualHost *:80>
    DocumentRoot /srv/app
</VirtualHost>" | sudo tee /etc/apache2/sites-available/techlog.conf
sudo a2ensite techlog.conf
sudo systemctl reload apache2

# Configurar IP estático (exemplo)
#sudo nano /etc/netplan/00-installer-config.yaml

# Configurar firewall
sudo ufw allow 22
sudo ufw allow 80
sudo ufw enable
